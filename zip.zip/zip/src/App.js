import './App.css';


import TodoList from './components/TodoComp';

function App() {
  return (

    <>
      <h1 className='text-center m-4'>Todo Tasks</h1>
      <TodoList />
    </>

  );
}

export default App;
